import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Model } from '../../../datamodels/model';
import { ModelService } from '../../../services/model.service';
import { BaseDetailComponent } from '../../../shared/base-detail.component';

@Component({
  selector: 'app-model-detail',
  templateUrl: './model-detail.component.html',
  styleUrls: ['./model-detail.component.css']
})
export class ModelDetailComponent extends BaseDetailComponent<Model> {
  modelForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private modelService: ModelService
  ) {
    super();
    this.modelForm = this.createForm();
  }

  protected loadItem(id: string): void {
    this.modelService.getModel(id).subscribe({
      next: (model) => {
        this.item = model;
        this.populateForm(model);
      },
      error: (error) => console.error('Error loading model:', error)
    });
  }

  protected createNewItem(): Model {
    return {
      modelUId: '',
      name: '',
      type: '',
      version: '',
      description: '',
      provider: '',
      endpoint: '',
      apiKey: '',
      region: '',
      isEnabled: true,
      createdBy: 'Current User',
      createdDate: new Date(),
      modifiedBy: 'Current User',
      modifiedDate: new Date(),
      correlationUId: '',
      rowVersion: new Uint8Array(),
      metadata: []
    };
  }

  protected saveItem(): void {
    if (this.modelForm.valid) {
      const formValue = this.modelForm.value;
      const modelToSave: Model = {
        ...this.item,
        ...formValue,
        modifiedBy: 'Current User',
        modifiedDate: new Date()
      };

      const saveOperation = this.item.modelUId 
        ? this.modelService.updateModel(modelToSave)
        : this.modelService.createModel(modelToSave);

      saveOperation.subscribe({
        next: (savedModel) => {
          this.item = savedModel;
          console.log('Model saved successfully');
          this.navigateBack();
        },
        error: (error) => console.error('Error saving model:', error)
      });
    }
  }

  protected deleteItem(): void {
    if (this.item?.modelUId && confirm('Are you sure you want to delete this model?')) {
      this.modelService.deleteModel(this.item.modelUId).subscribe({
        next: () => {
          console.log('Model deleted successfully');
          this.navigateBack();
        },
        error: (error) => console.error('Error deleting model:', error)
      });
    }
  }

  private createForm(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(100)]],
      type: ['', Validators.maxLength(50)],
      version: ['', Validators.maxLength(20)],
      description: ['', Validators.maxLength(500)],
      provider: ['', Validators.maxLength(100)],
      endpoint: ['', Validators.maxLength(500)],
      apiKey: ['', Validators.maxLength(200)],
      region: ['', Validators.maxLength(50)],
      isEnabled: [true]
    });
  }

  private populateForm(model: Model): void {
    this.modelForm.patchValue({
      name: model.name,
      type: model.type,
      version: model.version,
      description: model.description,
      provider: model.provider,
      endpoint: model.endpoint,
      apiKey: model.apiKey,
      region: model.region,
      isEnabled: model.isEnabled
    });
  }

  get isFormValid(): boolean {
    return this.modelForm.valid;
  }

  get isEditMode(): boolean {
    return !!this.item?.modelUId;
  }
}
