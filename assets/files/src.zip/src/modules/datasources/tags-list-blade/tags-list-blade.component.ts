import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';

@Component({
    selector: 'app-tags-list-blade',
    standalone: false,
    templateUrl: './tags-list-blade.component.html',
    styleUrls: ['./tags-list-blade.component.css']
})
export class TagsListBladeComponent implements OnChanges {
    @Input() tags: string[] = [];
    @Input() sourceType: string = '';
    @Input() sourceId: string = '';
    @Input() isOpen: boolean = false;
    @Output() close = new EventEmitter<void>();
    @Output() openRelatedBlade = new EventEmitter<any>();

    editMode = false;
    tagsToEdit: string[] = [];

    ngOnChanges(changes: SimpleChanges) {
        if (changes['tags'] && this.tags) {
            this.tagsToEdit = [...this.tags];
        }
    }

    onClose() {
        this.close.emit();
    }

    toggleEdit() {
        this.editMode = !this.editMode;
        if (this.editMode) {
            this.tagsToEdit = [...this.tags];
        }
    }

    addTag() {
        this.tagsToEdit.push('');
    }

    removeTag(index: number) {
        this.tagsToEdit.splice(index, 1);
    }

    onSave() {
        // Filter out empty tags
        this.tagsToEdit = this.tagsToEdit.filter(tag => tag.trim() !== '');
        // Emit save event or call service
        console.log('Saving tags:', this.tagsToEdit);
        this.editMode = false;
    }

    onCancel() {
        this.tagsToEdit = [...this.tags];
        this.editMode = false;
    }

    trackByIndex(index: number): number {
        return index;
    }
}
