export interface BladeStackItem {
  type: 'data-source-detail' | 'data-source-add' | 'data-source-edit';
  data: {
    dataSourceId: string | null;
    mode: 'add' | 'view' | 'edit';
  };
}

export type BladeStack = BladeStackItem[];
