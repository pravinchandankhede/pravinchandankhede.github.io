export interface BladeStackItem {
  type: 'data-source-detail' | 'tags-list' | 'connection-details' | 'collection-list' | 'chunk-list';
  data: {
    dataSourceId?: string | null;
    collectionId?: string | null;
    mode?: 'add' | 'view' | 'edit';
    tags?: string[];
    connectionType?: string;
    [key: string]: any; // Allow additional properties for different blade types
  };
}

export type BladeStack = BladeStackItem[];
