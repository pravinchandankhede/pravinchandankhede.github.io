import { DataSourceDetailBladeComponent } from '../data-source-detail-blade/data-source-detail-blade.component';

export function bladeFactory(blade: any) {
  switch (blade.type) {
    case 'data-source-detail':
      return DataSourceDetailBladeComponent;
    default:
      return null;
  }
}
