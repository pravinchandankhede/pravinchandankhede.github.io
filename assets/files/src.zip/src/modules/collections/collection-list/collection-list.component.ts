import { Component, signal } from '@angular/core';
import { Router } from '@angular/router';
import { DataSourceCollection } from '../../../datamodels/data-source-collection.model';
import { BaseListComponent } from '../../../shared/base-list.component';
import { ErrorService } from '../../../services/error.service';
import { DataSourceCollectionService } from '../../../services/data-source-collection.service';
import { BladeStackItem } from '../../../shared/types/blade-stack.types';

@Component({
    selector: 'app-collection-list',
    standalone: false,
    templateUrl: './collection-list.component.html',
    styleUrls: ['./collection-list.component.css']
})
export class CollectionListComponent extends BaseListComponent<DataSourceCollection> {
    bladeStack = signal<BladeStackItem[]>([]);

    constructor(
        private router: Router,
        private errorService: ErrorService,
        private collectionService: DataSourceCollectionService
    ) {
        super();
    }

    fetchItems(): void {
        // TODO: Replace with actual service call when available
         this.collectionService.getDataSourceCollections().subscribe({
           next: (data: DataSourceCollection[]) => {
             this.items = data;
             this.applyFilter();
             if (this.items.length === 0) {
               this.errorService.addError('No collections found.', 'Collection List');
             }
           },
           error: (err: any) => {
             let message = 'Failed to load collections.';
             if ([0, 502, 503, 504].includes(err.status)) {
               message = 'Cannot connect to collection service. Please check your network or server.';
             } else if (err.error && typeof err.error === 'string') {
               message = err.error;
             } else if (err.message) {
               message = err.message;
             }
             this.errorService.addError(message, 'Collection List');
           }
         });
    }

    filterPredicate(collection: DataSourceCollection): boolean {
        return collection.name.toLowerCase().includes(this.searchTerm.toLowerCase());
    }

    onAdd() {
        this.openCollectionBlade(null, 'add');
    }

    onSelect(collection: DataSourceCollection) {
        this.openCollectionBlade(collection, 'view');
    }

    onEdit(collection: DataSourceCollection) {
        this.openCollectionBlade(collection, 'edit');
    }

    onView(collection: DataSourceCollection) {
        this.openCollectionBlade(collection, 'view');
    }

    private openCollectionBlade(collection: DataSourceCollection | null, mode: 'view' | 'edit' | 'add') {
        this.bladeStack.update((stack: BladeStackItem[]) => [
            ...stack,
            {
                type: 'collection-detail',
                title: mode === 'add' ? 'Add Collection' : collection?.name || 'Collection Details',
                data: { collection, mode }
            }
        ]);
    }

    onCloseBlade(index: number) {
        this.bladeStack.update((stack: BladeStackItem[]) => stack.slice(0, index));
    }

    onOpenRelatedBlade(blade: BladeStackItem) {
        this.bladeStack.update((stack: BladeStackItem[]) => [...stack, blade]);
    }

    onSaveCollection(collection: DataSourceCollection) {
        // TODO: Implement actual save logic
        console.log('Saving collection:', collection);
        this.onCloseBlade(this.bladeStack().length - 1);
        this.fetchItems(); // Refresh the list
    }
}
