import { Component, Input, Output, EventEmitter, signal } from '@angular/core';
import { DataSource } from '../../../datamodels/data-source.model';
import { DataSourceCollection } from '../../../datamodels/data-source-collection.model';
import { BladeStackItem } from '../../../shared/types/blade-stack.types';

@Component({
  selector: 'app-data-sources-list-blade',
  standalone: false,
  templateUrl: './data-sources-list-blade.component.html',
  styleUrls: ['./data-sources-list-blade.component.css']
})
export class DataSourcesListBladeComponent {
  @Input() dataSources: DataSource[] = [];
  @Input() parentCollection: DataSourceCollection | null = null;
  @Input() mode: 'view' | 'edit' = 'view';
  @Input() bladeIndex: number = 0;
  
  @Output() close = new EventEmitter<void>();
  @Output() dataSourcesChanged = new EventEmitter<DataSource[]>();
  @Output() openRelatedBlade = new EventEmitter<BladeStackItem>();

  searchTerm = signal('');
  
  get filteredDataSources() {
    const term = this.searchTerm().toLowerCase();
    if (!term) return this.dataSources;
    
    return this.dataSources.filter(ds => 
      ds.name?.toLowerCase().includes(term) ||
      ds.dataSourceUId?.toLowerCase().includes(term) ||
      ds.description?.toLowerCase().includes(term)
    );
  }

  onClose() {
    this.close.emit();
  }

  onAddDataSource() {
    // Emit event to open data source selection blade
    this.openRelatedBlade.emit({
      type: 'data-source-selection',
      title: 'Select Data Source',
      data: { 
        excludedIds: this.dataSources.map(ds => ds.dataSourceUId),
        parentCollection: this.parentCollection
      }
    });
  }

  onRemoveDataSource(dataSource: DataSource) {
    if (this.mode === 'edit') {
      const updatedDataSources = this.dataSources.filter(ds => ds.dataSourceUId !== dataSource.dataSourceUId);
      this.dataSourcesChanged.emit(updatedDataSources);
    }
  }

  onViewDataSource(dataSource: DataSource) {
    this.openRelatedBlade.emit({
      type: 'data-source-detail',
      title: dataSource.name || 'Data Source Details',
      data: { dataSource, mode: 'view' }
    });
  }

  getStatusBadgeClass(dataSource: DataSource): string {
    // Add logic based on data source status if available
    return 'status-active';
  }

  getConnectionTypeIcon(dataSource: DataSource): string {
    // Return appropriate icon based on data source type
    switch (dataSource.type) {
      case 'Vector': return 'scatter_plot';
      case 'Structured': return 'table_view';
      case 'SemiStructured': return 'account_tree';
      case 'Unstructured': return 'description';
      case 'Multimedia': return 'perm_media';
      case 'Streaming': return 'stream';
      default: return 'source';
    }
  }

  trackByDataSourceId(index: number, dataSource: DataSource): string {
    return dataSource.dataSourceUId;
  }
}
