import { Component, Input, Output, EventEmitter, OnInit, signal } from '@angular/core';
import { DataSourceCollection } from '../../../datamodels/data-source-collection.model';
import { DataSource } from '../../../datamodels/data-source.model';
import { BladeStackItem } from '../../../shared/types/blade-stack.types';

@Component({
  selector: 'app-collection-detail-blade',
  standalone: false,
  templateUrl: './collection-detail-blade.component.html',
  styleUrls: ['./collection-detail-blade.component.css']
})
export class CollectionDetailBladeComponent implements OnInit {
  @Input() collection: DataSourceCollection | null = null;
  @Input() mode: 'view' | 'edit' | 'add' = 'view';
  @Input() bladeIndex: number = 0;
  
  @Output() close = new EventEmitter<void>();
  @Output() save = new EventEmitter<DataSourceCollection>();
  @Output() openRelatedBlade = new EventEmitter<BladeStackItem>();

  editedCollection = signal<DataSourceCollection | null>(null);

  ngOnInit() {
    if (this.collection) {
      this.editedCollection.set({ ...this.collection });
    } else if (this.mode === 'add') {
      this.editedCollection.set({
        dataSourceCollectionUId: '',
        name: '',
        description: '',
        isCustom: true,
        dataSources: [],
        createdDate: new Date(),
        lastModifiedDate: new Date()
      });
    }
  }

  onSave() {
    const collection = this.editedCollection();
    if (collection) {
      this.save.emit(collection);
    }
  }

  onCancel() {
    this.close.emit();
  }

  openDataSourcesBlade() {
    const collection = this.editedCollection();
    if (collection && collection.dataSources) {
      this.openRelatedBlade.emit({
        type: 'data-sources-list',
        title: 'Data Sources',
        data: { dataSources: collection.dataSources, parentCollection: collection }
      });
    }
  }

  isComplexField(value: any): boolean {
    return Array.isArray(value) && value.length > 0;
  }

  getFieldDisplayValue(value: any): string {
    if (Array.isArray(value)) {
      return `${value.length} item(s)`;
    }
    if (typeof value === 'object' && value !== null) {
      return 'Object';
    }
    return value?.toString() || '';
  }

  onFieldClick(fieldName: string, value: any) {
    if (fieldName === 'dataSources' && Array.isArray(value)) {
      this.openDataSourcesBlade();
    }
  }
}
