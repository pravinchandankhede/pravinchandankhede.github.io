import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { CollectionListComponent } from './collection-list/collection-list.component';
import { CollectionDetailComponent } from './collection-detail/collection-detail.component';
import { CollectionDetailBladeComponent } from './collection-detail-blade/collection-detail-blade.component';
import { DataSourcesListBladeComponent } from './data-sources-list-blade/data-sources-list-blade.component';
import { CollectionsRoutingModule } from './collections-routing.module';
import { DataSourcesModule } from '../datasources/datasources.module';

@NgModule({
    declarations: [
        CollectionListComponent,
        CollectionDetailComponent,
        CollectionDetailBladeComponent,
        DataSourcesListBladeComponent
    ],
    imports: [
        CommonModule,
        MatIconModule,
        FormsModule,
        CollectionsRoutingModule,
        DataSourcesModule
    ],
    exports: [
        CollectionDetailBladeComponent,
        DataSourcesListBladeComponent
    ]
})
export class CollectionsModule { }
