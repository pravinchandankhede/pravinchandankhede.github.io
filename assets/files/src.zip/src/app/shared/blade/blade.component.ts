import { Component, Input } from '@angular/core';

@Component({
  selector: 'blade',
  templateUrl: './blade.component.html',
  styleUrls: ['./blade.component.scss'],
  standalone: true
})
export class BladeComponent {
  @Input() blade: any;
  @Input() index!: number;
  @Input() total!: number;
}
