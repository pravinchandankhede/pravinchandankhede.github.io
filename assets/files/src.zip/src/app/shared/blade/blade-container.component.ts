import { Component, Input } from '@angular/core';

@Component({
  selector: 'blade-container',
  templateUrl: './blade-container.component.html',
  styleUrls: ['./blade-container.component.scss'],
  standalone: true
})
export class BladeContainerComponent {
  @Input() blades: any[] = [];
}
