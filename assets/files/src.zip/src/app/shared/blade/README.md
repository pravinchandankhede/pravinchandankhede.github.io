# Blade UI System

## Components

- `BladeContainerComponent`: Hosts and manages a stack of blades. Use this as the root for any blade-based UI region.
- `BladeComponent`: Represents a single blade. Accepts content via `ng-content` slots for header, content, and footer.

## Usage Example

```
<blade-container [blades]="bladeStack"></blade-container>
```

Where `bladeStack` is an array of blade config objects, e.g.:

```
bladeStack = [
  { type: 'collection-detail', data: { ... } },
  { type: 'data-source-list', data: { ... } },
  { type: 'data-source-detail', data: { ... } }
];
```

## Theming

- All blade components use CSS variables defined in `src/styles/theme.scss`.
- Supports light/dark mode and custom branding.

## Best Practices

- Use strong typing for blade config objects.
- Keep blade logic in feature modules, but use shared blade components for layout and transitions.
- Use OnPush change detection for performance.
- Follow Angular and BEM naming conventions for all new code.
