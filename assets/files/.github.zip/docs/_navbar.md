<!-- Navigation bar -->
- [🏠 Home](/)
- [📚 Documentation](/README.md)
- [🚀 Quick Start](/getting-started/README.md)
- [👨‍💻 Development](/development/standards.md)
- [🏗️ Architecture](/architecture/overview.md)
- [📞 Support](https://github.com/your-org/matrix-portal/issues)
