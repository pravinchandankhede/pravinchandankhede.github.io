﻿namespace Matrix.DataModels.Agents;

public class AgentRequest
{
    public required String Query { get; set; }
}
