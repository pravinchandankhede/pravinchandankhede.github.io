import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { DataSourceDetailComponent } from './data-source-detail.component';
import { StructuredConnectionDetailsComponent } from './structured-connection-details/structured-connection-details.component';
import { VectorConnectionDetailsComponent } from './vector-connection-details/vector-connection-details.component';

@NgModule({
  declarations: [
    DataSourceDetailComponent,
    StructuredConnectionDetailsComponent,
    VectorConnectionDetailsComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule
  ],
  exports: [DataSourceDetailComponent]
})
export class DataSourceDetailModule {}
