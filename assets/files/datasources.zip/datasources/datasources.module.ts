import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataSourceListComponent } from './data-source-list/data-source-list.component';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { DataSourcesRoutingModule } from './datasources-routing.module';
import { DataSourceDetailModule } from './data-source-detail/data-source-detail.module';

@NgModule({
    declarations: [
        DataSourceListComponent,
    ],
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        MatIconModule,
        FormsModule,
        DataSourcesRoutingModule,
        DataSourceDetailModule
    ]
})
export class DataSourcesModule { }

