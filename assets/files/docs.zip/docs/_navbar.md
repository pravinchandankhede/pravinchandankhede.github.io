<nav>
  <a href="#/platform-overview/README">Platform Overview</a> |
  <a href="#/architecture/README">Architecture</a> |
  <a href="#/portal-overview/README">Portal</a> |
  <a href="#/api-reference/README">API Reference</a>
</nav>
