# REST API

Document the available REST API endpoints, request/response formats, and usage examples.
