# User Interface

Description of the main UI components and navigation.
